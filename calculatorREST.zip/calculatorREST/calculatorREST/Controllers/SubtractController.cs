﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace calculatorREST.Controllers
{
    [Route("api/[controller]")]
    public class SubtractController : Controller
    {
        [HttpGet]
        public IEnumerable<decimal> Get(decimal num1, decimal num2)
        {
            var num = num1 - num2;
            // yield return "subtract of number1 " + num1 + " and number2 " + num2 + ": " + num;
            yield return num;
        }
    }
}

